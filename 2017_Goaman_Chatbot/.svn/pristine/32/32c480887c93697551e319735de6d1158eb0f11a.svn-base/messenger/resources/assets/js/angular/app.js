var messengerBotApp = angular.module("messengerBotApp", [
    "ngAnimate",
    "ui.bootstrap",
    "toastr",
    "ui.sortable",
    "messengerBotApp.global.ngSweetAlert",
    "messengerBotApp.global.facebookService",
    "ngSanitize",
    "ui.select",
    "chart.js",
    "daterangepicker"
]);