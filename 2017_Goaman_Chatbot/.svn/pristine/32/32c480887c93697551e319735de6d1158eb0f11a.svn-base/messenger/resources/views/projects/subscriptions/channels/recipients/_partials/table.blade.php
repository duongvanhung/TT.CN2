<table class="table custom-table">
    <thead>
        <tr>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>First name</th>
            <th>Last name</th>
            <th>Added</th>
            <th>Type</th>
            <th>&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        @foreach($recipients as $recipient)
            <tr>
                <td class="text-center">
                    @if($recipient->getPhotoUrl('recipient_small'))
                        <img class="img-circle" src="{{ $recipient->getPhotoUrl('recipient_small') }}">
                    @else
                        &nbsp;
                    @endif
                </td>
                <td class="text-center">
                    @if($recipient->gender == 'male')
                        <i class="fa fa-mars"></i>
                    @elseif($recipient->gender == 'female')
                        <i class="fa fa-venus"></i>
                    @else
                        -
                    @endif
                </td>
                <td>{{ $recipient->first_name }}</td>
                <td>{{ $recipient->last_name }}</td>
                <td>{{ $recipient->pivot->created_at ? adjust_project_timezone($project, $recipient->pivot->created_at)->format('F j, Y, g:i A') : '' }}</td>
                <td>{{ $recipient->pivot->type or '-' }}</td>
                <td class="text-right">
                    <form method="POST" action="{{ route('projects.subscriptions.channels.recipients.delete', [$project->id, $channel->id, $recipient->id]) }}">
                        {!! csrf_field() !!}
                        {!! method_field('DELETE') !!}
                        <button type="submit" class="btn btn-danger confirm-action" data-toggle="tooltip" title="Remove"><i class="fa fa-trash"></i></button>
                        <a href="{{ route('projects.recipients.show', [$project->id, $recipient->id]) }}" class="btn btn-default"><i class="fa fa-arrow-right"></i></a>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>