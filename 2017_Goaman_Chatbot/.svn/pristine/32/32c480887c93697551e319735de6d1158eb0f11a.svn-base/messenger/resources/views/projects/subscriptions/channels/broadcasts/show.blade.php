@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}">Channels</a> &raquo; <a href="{{ route('projects.subscriptions.channels.show', [$project->id, $channel->id]) }}">{{ $channel->name }}</a> &raquo; <a href="{{ route('projects.subscriptions.channels.broadcasts.index', [$project->id, $channel->id]) }}">Broadcasts</a> &raquo; {{ $broadcast->name }}</div>
                <div class="pull-right">
                    <form method="POST" action="{{ route('projects.subscriptions.channels.broadcasts.delete', [$project->id, $channel->id, $broadcast->id]) }}">
                        {!! csrf_field() !!}
                        {!! method_field('DELETE') !!}
                        <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                        <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                        <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                        <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                        <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                        <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                        @can('delete', [$broadcast, $channel, $project])
                            <button class="btn btn-danger confirm-action" type="submit" data-toggle="tooltip" title="Delete"><i class="fa fa-trash"></i></button>
                        @endcan
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    @notification()

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Broadcast information
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-6">
                            <dl class="dl-horizontal">
                                <dt>Scheduled</dt>
                                <dd>{{ $broadcast->scheduled_at ? adjust_project_timezone($project, $broadcast->scheduled_at)->format('F j, Y, g:i A') : '' }}</dd>
                            </dl>
                        </div>
                        <div class="col-md-6">
                            <dl class="dl-horizontal">
                                <dt>Finished</dt>
                                <dd>{{ $broadcast->finished_at ? adjust_project_timezone($project, $broadcast->finished_at)->format('F j, Y, g:i A') : 'not finished yet' }}</dd>
                            </dl>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <dl class="dl-horizontal">
                                <dt>Respond</dt>
                                <dd>
                                    @if($broadcast->respond)
                                        <a href="{{ route('projects.responds.edit', [$project->id, $broadcast->respond->id]) }}" class="btn btn-primary btn-xs">
                                            {{ $broadcast->respond->title }}
                                        </a>
                                    @else
                                        There is nothing to be sent :(
                                    @endif
                                </dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Schedules</div>
                @if(count($schedules) <= 0)
                    <div class="panel-body">
                        No schedules found.
                    </div>
                @else
                    <table class="table custom-table">
                        <thead>
                        <tr>
                            <th colspan="2">Recipient</th>
                            <th>Timezone</th>
                            <th>Scheduled</th>
                            <th>Sent</th>
                        </tr>
                        </thead>
                        <tbody>
                            @foreach($schedules as $schedule)
                                <tr>
                                    <td class="text-center" style="width: 60px;">
                                        @if($schedule->recipient->getPhotoUrl('recipient_small'))
                                            <img class="img-circle" src="{{ $schedule->recipient->getPhotoUrl('recipient_small') }}">
                                        @else
                                            &nbsp;
                                        @endif
                                    </td>
                                    <td>{{ $schedule->recipient->display_name }}</td>
                                    <td>{{ $schedule->recipient->timezone or '-' }}</td>
                                    <td>{{ adjust_project_timezone($project, $schedule->scheduled_at)->format('F j, Y, g:i:s A') }}</td>
                                    <td>{{ $schedule->sent_at ? adjust_project_timezone($project, $schedule->sent_at)->format('F j, Y, g:i:s A') : 'not sent yet' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>
    </div>

    @if($schedules->hasPages())
        <div class="text-center">
            {!! $schedules->render() !!}
            </div>
        @endif
    </div>
@endsection