@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}">Channels</a> &raquo; <a href="{{ route('projects.subscriptions.channels.show', [$project->id, $channel->id]) }}">{{ $channel->name }}</a> &raquo; Recipients</div>
                <div class="pull-right">
                    <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.recipients.create', [$project->id, $channel->id]) }}" class="btn btn-success"><i class="fa fa-btn fa-plus"></i>Add recipient</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        @notification()

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Subscribers growth for last 30 days</div>
                    <div class="panel-body">
                        @widget('App\Widgets\Statistics\Channel\SubscribersGrowth', ['channel' => $channel])
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-push-2">
                <div class="panel panel-default">
                    <form method="GET" action="{{ route('projects.subscriptions.channels.recipients.index', [$project->id, $channel->id]) }}">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search for..." value="{{ $search }}">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default{{ $search && count($recipients) <= 0 ? ' panel-info' : '' }}">
                    @if(count($recipients) <= 0)
                        <div class="panel-body">
                            @if($search)
                                No recipients found.
                            @else
                                You have no recipients in this channel! <a href="{{ route('projects.subscriptions.channels.recipients.create', [$project->id, $channel->id]) }}">Add</a> new recipient.
                            @endif
                        </div>
                    @else
                        @include('projects.subscriptions.channels.recipients._partials.table', ['project' => $project, 'channel' => $channel, 'recipients' => $recipients])
                    @endif
                </div>
            </div>
        </div>

        @if($recipients->hasPages())
            <div class="text-center">
                {!! $recipients->render() !!}
            </div>
        @endif
    </div>
@endsection