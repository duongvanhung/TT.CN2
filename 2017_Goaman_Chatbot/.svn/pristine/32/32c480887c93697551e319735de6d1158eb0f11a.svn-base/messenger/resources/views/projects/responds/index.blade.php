@extends('layouts.app')

@push('head_scripts')
    <script type="text/javascript" xmlns="http://www.w3.org/1999/html">
        var PROJECT_ID = {{ $project->id }};
        var PROJECT_TIMEZONE = "{{ $project->timezone }}";
    </script>
@endpush

@section('content')
    <div ng-controller="RespondsController">
        <div class="content-header">
            <div class="container">
                <div class="clearfix">
                    <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; Responds</div>
                    <div class="pull-right">
                        <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                        <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                        <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                        <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                        <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                        <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                        <a href="{{ route('projects.responds.create', $project->id) }}" class="btn btn-success"><i class="fa fa-btn fa-plus"></i>Add respond</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            @notification()

            <div class="row" ng-show="respondsLoading">
                <div class="col-md-12 text-center">
                    <p>Initializing responds...</p>
                </div>
            </div>

            <div class="row" ng-show="!respondsLoading && (responds.length <= 0 || !responds)" ng-cloak>
                <div class="col-md-12">
                    <div class="alert alert-info">No responds found.</div>
                </div>
            </div>

            <div ng-show="responds.length > 0 && !respondsLoading" ng-cloak>
                <div class="row">
                    <div class="col-md-8 col-md-push-2">
                        <div class="panel panel-default">
                            <input type="text" name="search" class="form-control" placeholder="Search for..." ng-model="search">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 social-accounts">
                        <ul class="responds-list list-unstyled">
                            <li class="col-md-4" ng-repeat="respond in responds | filter : search as filtered_responds track by respond.id">
                                <div class="panel panel-default respond-item">
                                    <div class="title">
                                        <a respond-href="respond" uib-tooltip="@{{ respond.title }}" tooltip-trigger="mouseenter">
                                            @{{ respond.title | truncate:30}}
                                        </a>
                                        <button type="button" class="close" ng-click="deleteRespond(respond)" uib-tooltip="Delete respond" tooltip-trigger="mouseenter"><i class="fa fa-times"></i></button>
                                    </div>
                                    <div class="clearfix">
                                        <small class="date pull-right" project-time time="respond.updated_at"></small>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="row" ng-show="filtered_responds.length <= 0">
                    <div class="col-md-12">
                        <div class="alert alert-info">No responds found.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection