@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; <a href="{{ route('projects.recipients.index', $project->id) }}">Recipients</a> &raquo; @if($recipient->getPhotoUrl('recipient_small')) <img class="img-circle" src="{{ $recipient->getPhotoUrl('recipient_small') }}"> @endif {{ $recipient->display_name }}</div>
                <div class="pull-right">
                    <form method="POST" action="{{ route('projects.recipients.chat.toggle', [$project->id, $recipient->id]) }}">
                        {!! csrf_field() !!}
                        <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                        <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                        <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                        <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                        <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                        <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                        <a href="{{ route('projects.recipients.edit', [$project->id, $recipient->id]) }}" class="btn btn-warning" data-toggle="tooltip" title="Edit"><i class="fa fa-pencil"></i></a>
                        <a href="{{ route('projects.recipients.refresh', [$project->id, $recipient->id]) }}" class="btn btn-info" data-toggle="tooltip" title="Refresh data from API"><i class="fa fa-refresh"></i></a>
                        @if($recipient->chat_disabled)
                            <button class="btn btn-link" type="submit" name="action" value="enable" data-toggle="tooltip" title="Enable chat"><i class="fa fa-toggle-off"></i></button>
                        @else
                            <button class="btn btn-link" type="submit" name="action" value="disable" data-toggle="tooltip" title="Disable chat"><i class="fa fa-toggle-on"></i></button>
                        @endif
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        @notification()

        @if($recipient->chat_disabled)
            <div class="alert alert-warning">
                Auto chat for this user is disabled.
            </div>
        @endif

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Recipient information
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            @foreach($recipientVariables as $recipientVariable)
                                <div class="col-md-4">
                                    @include('projects.recipients.variables.render.render', ['recipientVariable' => $recipientVariable])
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @if(count($subscriptions_channels) > 0)
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">Subscribed channels</div>
                        <table class="table custom-table">
                            <thead>
                                <tr>
                                    <th>Channel</th>
                                    <th>Added</th>
                                    <th>Type</th>
                                    <th>&nbsp;</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($subscriptions_channels as $channel)
                                    <tr>
                                        <td>{{ $channel->name }}</td>
                                        <td>{{ $channel->pivot->created_at ? adjust_project_timezone($project, $channel->pivot->created_at)->format('F j, Y, g:i A') : '' }}</td>
                                        <td>{{ $channel->pivot->type or '-' }}</td>
                                        <td class="text-right">
                                            <form method="POST" action="{{ route('projects.subscriptions.channels.recipients.delete', [$project->id, $channel->id, $recipient->id]) }}">
                                                {!! csrf_field() !!}
                                                {!! method_field('DELETE') !!}
                                                <button type="submit" class="btn btn-danger confirm-action" data-toggle="tooltip" title="Remove"><i class="fa fa-trash"></i></button>
                                                <a href="{{ route('projects.subscriptions.channels.show', [$project->id, $channel->id]) }}" class="btn btn-default"><i class="fa fa-arrow-right"></i></a>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endif

        <div class="row">
            <div class="col-md-8 col-md-push-2">
                <div class="panel panel-default">
                    <form method="GET" action="{{ route('projects.recipients.show', ['project' => $project->id, 'recipient' => $recipient]) }}">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search for..." value="{{ $search }}">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Communication log</div>
                    @if(count($communication_log) <= 0)
                        <div class="panel-body">
                            No communication log found.
                        </div>
                    @else
                        <table class="table custom-table">
                            <thead>
                            <tr>
                                <th>Message</th>
                                <th>Matched flow</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>
                                @foreach($communication_log as $communication_log_item)
                                    <tr>
                                        <td>{{ $communication_log_item->message }}</td>
                                        <td>
                                            @if($communication_log_item->flow)
                                                {{ $communication_log_item->flow->title }}
                                            @else
                                                -
                                            @endif
                                        </td>
                                        <td>{{ adjust_project_timezone($project, $communication_log_item->created_at)->format('F j, Y, g:i:s A') }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                </div>
            </div>
        </div>

        @if($communication_log->hasPages())
            <div class="text-center">
                {!! $communication_log->render() !!}
            </div>
        @endif
    </div>
@endsection