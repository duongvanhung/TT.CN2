@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; Recipients variables</div>
                <div class="pull-right">
                    <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                    <a href="{{ route('projects.recipients.variables.create', $project->id) }}" class="btn btn-success"><i class="fa fa-btn fa-plus"></i>Add variable</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        @notification()

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    @if(count($recipientsVariables) <= 0)
                        <div class="panel-body">
                            You have no variables in this project! <a href="{{ route('projects.recipients.variables.create', $project->id) }}">Add</a> new variable.
                        </div>
                    @else
                        @include('projects.recipients.variables._partials.table', ['recipientsVariables' => $recipientsVariables])
                    @endif
                </div>
            </div>
        </div>

        @if($recipientsVariables->hasPages())
            <div class="text-center">
                {!! $recipientsVariables->render() !!}
            </div>
        @endif
    </div>
@endsection