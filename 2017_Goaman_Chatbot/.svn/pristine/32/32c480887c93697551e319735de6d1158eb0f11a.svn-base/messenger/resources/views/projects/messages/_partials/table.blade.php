<table class="table custom-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Scheduled</th>
            <th>Finished</th>
            <th>Created</th>
            <th>&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        @foreach($messages as $message)
            <tr>
                <td>{{ $message->name }}</td>
                <td>{{ $message->scheduled_at ? adjust_project_timezone($project, $message->scheduled_at)->format('F j, Y, g:i A') : '' }}</td>
                <td>{{ $message->finished_at ? adjust_project_timezone($project, $message->finished_at)->format('F j, Y, g:i A') : 'not finished yet' }}</td>
                <td>{{ $message->created_at ? adjust_project_timezone($project, $message->created_at)->format('F j, Y, g:i A') : '' }}</td>
                <td class="text-right">
                    <form method="POST" action="{{ route('projects.messages.delete', [$project->id, $message->id]) }}">
                        {!! csrf_field() !!}
                        {!! method_field('DELETE') !!}
                        @can('delete', [$message, $project])
                            <button class="btn btn-danger confirm-action" type="submit" data-toggle="tooltip" title="Delete"><i class="fa fa-trash"></i></button>
                        @endcan
                        <a href="{{ route('projects.messages.show', [$project->id, $message->id]) }}" class="btn btn-default"><i class="fa fa-arrow-right"></i></a>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>