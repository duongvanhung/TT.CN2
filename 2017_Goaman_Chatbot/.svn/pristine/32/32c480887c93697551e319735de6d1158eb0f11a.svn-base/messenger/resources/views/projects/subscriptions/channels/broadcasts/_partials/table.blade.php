<table class="table custom-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Scheduled</th>
            <th>Finished</th>
            <th>Created</th>
            <th>&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        @foreach($broadcasts as $broadcast)
            <tr>
                <td>{{ $broadcast->name }}</td>
                <td>{{ $broadcast->scheduled_at ? adjust_project_timezone($project, $broadcast->scheduled_at)->format('F j, Y, g:i A') : '' }}</td>
                <td>{{ $broadcast->finished_at ? adjust_project_timezone($project, $broadcast->finished_at)->format('F j, Y, g:i A') : 'not finished yet' }}</td>
                <td>{{ $broadcast->created_at ? adjust_project_timezone($project, $broadcast->created_at)->format('F j, Y, g:i A') : '' }}</td>
                <td class="text-right">
                    <form method="POST" action="{{ route('projects.subscriptions.channels.broadcasts.delete', [$project->id, $channel->id, $broadcast->id]) }}">
                        {!! csrf_field() !!}
                        {!! method_field('DELETE') !!}
                        @can('delete', [$broadcast, $channel, $project])
                            <button class="btn btn-danger confirm-action" type="submit" data-toggle="tooltip" title="Delete"><i class="fa fa-trash"></i></button>
                        @endcan
                        <a href="{{ route('projects.subscriptions.channels.broadcasts.show', [$project->id, $channel->id, $broadcast->id]) }}" class="btn btn-default"><i class="fa fa-arrow-right"></i></a>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>