@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}">Channels</a> &raquo; <a href="{{ route('projects.subscriptions.channels.show', [$project->id, $channel->id]) }}">{{ $channel->name }}</a> &raquo; <a href="{{ route('projects.subscriptions.channels.recipients.index', [$project->id, $channel->id]) }}">Recipients</a> &raquo; Add recipient</div>
                <div class="pull-right">
                    <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        @notification()
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="{{ route('projects.subscriptions.channels.recipients.store', [$project->id, $channel->id]) }}" enctype="multipart/form-data">
                            {!! csrf_field() !!}

                            <div class="form-group{{ $errors->has('recipient') ? ' has-error' : '' }}">
                                <label class="col-md-4 control-label">Recipients</label>

                                <div class="col-md-6">
                                    <select class="form-control select2" multiple name="recipient[]">
                                        @foreach($recipients as $recipient)
                                            <option value="{{ $recipient->id }}" @if(in_array($recipient->id, (array) old('recipient'))) selected @endif>{{ $recipient->display_name }}</option>
                                        @endforeach
                                    </select>

                                    @if ($errors->has('recipient'))
                                        <span class="help-block">
                                        <strong>{{ $errors->first('recipient') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-save"></i>Save
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection