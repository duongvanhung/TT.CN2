@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; Mass messages</div>
                <div class="pull-right">
                    <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                    <a href="{{ route('projects.messages.create', $project->id) }}" class="btn btn-success"><i class="fa fa-btn fa-plus"></i>Schedule message</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        @notification()

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Mass messages sent of last 30 days</div>
                    <div class="panel-body">
                        @widget('App\Widgets\Statistics\Project\MassMessagesChart', ['project' => $project])
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    @if(count($messages) <= 0)
                        <div class="panel-body">
                            You have no mass messages in this project!
                        </div>
                    @else
                        @include('projects.messages._partials.table', ['messages' => $messages])
                    @endif
                </div>
            </div>
        </div>

        @if($messages->hasPages())
            <div class="text-center">
                {!! $messages->render() !!}
            </div>
        @endif
    </div>
@endsection