<table class="table custom-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Recipients</th>
            <th>Broadcasts</th>
            <th>Created</th>
            <th>Updated</th>
            <th>&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        @foreach($channels as $channel)
            <tr>
                <td>{{ $channel->name }}</td>
                <td>{{ $channel->recipients()->count() }}</td>
                <td>{{ $channel->broadcasts()->count() }}</td>
                <td>{{ $channel->created_at ? adjust_project_timezone($project, $channel->created_at)->format('F j, Y, g:i A') : '' }}</td>
                <td>{{ $channel->updated_at ? adjust_project_timezone($project, $channel->updated_at)->format('F j, Y, g:i A') : '' }}</td>
                <td class="text-right">
                    <form method="POST" action="{{ route('projects.subscriptions.channels.delete', [$project->id, $channel->id]) }}">
                        {!! csrf_field() !!}
                        {!! method_field('DELETE') !!}
                        @can('delete', [$channel, $project])
                            <button type="submit" class="btn btn-danger confirm-action" data-toggle="tooltip" title="Delete"><i class="fa fa-trash"></i></button>
                        @endcan
                        <a href="{{ route('projects.subscriptions.channels.edit', [$project->id, $channel->id]) }}" class="btn btn-warning" data-toggle="tooltip" title="Edit"><i class="fa fa-pencil"></i></a>
                        <a href="{{ route('projects.subscriptions.channels.show', [$project->id, $channel->id]) }}" class="btn btn-default" data-toggle="tooltip" title="Details"><i class="fa fa-arrow-right"></i></a>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>