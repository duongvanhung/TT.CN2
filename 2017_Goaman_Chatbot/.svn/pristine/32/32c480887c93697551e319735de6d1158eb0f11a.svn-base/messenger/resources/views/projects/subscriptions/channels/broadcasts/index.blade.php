@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}">Channels</a> &raquo; <a href="{{ route('projects.subscriptions.channels.show', [$project->id, $channel->id]) }}">{{ $channel->name }}</a> &raquo; Broadcasts</div>
                <div class="pull-right">
                    <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.broadcasts.create', [$project->id, $channel->id]) }}" class="btn btn-success"><i class="fa fa-btn fa-plus"></i>Broadcast new content</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        @notification()

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Broadcasted messages count for last 30 days</div>
                    <div class="panel-body">
                        @widget('App\Widgets\Statistics\Channel\BroadcastMessagesSent', ['channel' => $channel])
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-push-2">
                <div class="panel panel-default">
                    <form method="GET" action="{{ route('projects.subscriptions.channels.broadcasts.index', [$project->id, $channel->id]) }}">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search for..." value="{{ $search }}">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default{{ $search && count($broadcasts) <= 0 ? ' panel-info' : '' }}">
                    @if(count($broadcasts) <= 0)
                        <div class="panel-body">
                            @if($search)
                                No broadcasts found.
                            @else
                                You have no boradcasts in this channel! <a href="{{ route('projects.subscriptions.channels.broadcasts.create', [$project->id, $channel->id]) }}">Broadcast new content</a>.
                            @endif
                        </div>
                    @else
                        @include('projects.subscriptions.channels.broadcasts._partials.table', ['project' => $project, 'channel' => $channel, 'broadcasts' => $broadcasts])
                    @endif
                </div>
            </div>
        </div>

        @if($broadcasts->hasPages())
            <div class="text-center">
                {!! $broadcasts->render() !!}
            </div>
        @endif
    </div>
@endsection