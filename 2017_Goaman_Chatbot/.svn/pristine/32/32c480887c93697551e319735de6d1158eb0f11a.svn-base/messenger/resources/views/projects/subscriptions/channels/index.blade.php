@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; Channels</div>
                <div class="pull-right">
                    <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.create', $project->id) }}" class="btn btn-success"><i class="fa fa-btn fa-plus"></i>Add channel</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        @notification()

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Broadcasted messages count for last 30 days</div>
                    <div class="panel-body">
                        @widget('App\Widgets\Statistics\Project\BroadcastMessagesSentChart', ['project' => $project])
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-push-2">
                <div class="panel panel-default">
                    <form method="GET" action="{{ route('projects.subscriptions.channels.index', ['project' => $project->id]) }}">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search for..." value="{{ $search }}">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default{{ $search && count($channels) <= 0 ? ' panel-info' : '' }}">
                    @if(count($channels) <= 0)
                        <div class="panel-body">
                            @if($search)
                                No channels found.
                            @else
                                You have no channels in this project! <a href="{{ route('projects.subscriptions.channels.create', $project->id) }}">Add</a> new channel.
                            @endif
                        </div>
                    @else
                        @include('projects.subscriptions.channels._partials.table', ['channels' => $channels])
                    @endif
                </div>
            </div>
        </div>

        @if($channels->hasPages())
            <div class="text-center">
                {!! $channels->render() !!}
            </div>
        @endif
    </div>
@endsection