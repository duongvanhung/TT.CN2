@extends('layouts.app')

@section('content')
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="{{ route('projects.show', $project->id) }}">{{ $project->title }}</a> &raquo; <a href="{{ route('projects.recipients.variables.index', $project->id) }}">Recipients variables</a> &raquo; Add recipient variable</div>
                <div class="pull-right">
                    <a href="{{ route('projects.settings', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="{{ route('projects.recipients.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="{{ route('projects.recipients.variables.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="{{ route('projects.responds.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="{{ route('projects.messages.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="{{ route('projects.subscriptions.channels.index', $project->id) }}" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST" action="{{ route('projects.recipients.variables.store', $project->id) }}">
                            {!! csrf_field() !!}

                            <input type="hidden" name="type" value="text">

                            <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                                <label class="col-md-4 control-label">Name</label>

                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="name" value="{{ old('name') }}">

                                    @if ($errors->has('name'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('name') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fa fa-btn fa-save"></i>Save
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection