<?php

return [

    'text' => [
        'title' => [
            'text' => 'Text',
        ],
    ],

];
