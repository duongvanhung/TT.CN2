<?php

return [

    'equals' => [
        'title' => [
            'text' => 'Text',
            'case' => 'Case',
        ],
        'value' => [
            'case' => [
                'sensitive' => 'Case sensitive',
                'insensitive' => 'Case insensitive',
            ],
        ],
    ],

    'regex' => [
        'title' => [
            'pattern' => 'Pattern',
        ],
    ],

];
