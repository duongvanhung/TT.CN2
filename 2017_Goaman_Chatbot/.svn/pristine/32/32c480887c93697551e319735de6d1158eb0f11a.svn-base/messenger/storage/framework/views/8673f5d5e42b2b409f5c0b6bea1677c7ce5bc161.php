<?php $__env->startSection('form'); ?>
    <input type="hidden" name="option" value="url">
    <?php /*<div class="form-group<?php echo e($errors->has('option') ? ' has-error' : ''); ?>">*/ ?>
        <?php /*<label class="col-md-4 control-label">Option</label>*/ ?>

        <?php /*<div class="col-md-6">*/ ?>
            <?php /*<div class="btn-group" data-toggle="buttons">*/ ?>
                <?php /*<label class="btn btn-primary <?php echo e(old('option', 'url') == 'url' ? 'active' : ''); ?>">*/ ?>
                    <?php /*<input type="radio" name="option" value="url" id="optionURL" autocomplete="off" <?php echo e(old('option', 'url') == 'url' ? 'checked' : ''); ?>> URL*/ ?>
                <?php /*</label>*/ ?>
                <?php /*<label class="btn btn-primary <?php echo e(old('option', 'url') == 'upload' ? 'active' : ''); ?>">*/ ?>
                    <?php /*<input type="radio" name="option" value="upload" id="optionUpload" autocomplete="off" <?php echo e(old('option', 'url') == 'upload' ? 'active' : ''); ?>> Upload*/ ?>
                <?php /*</label>*/ ?>
            <?php /*</div>*/ ?>

            <?php /*<?php if($errors->has('option')): ?>*/ ?>
                <?php /*<span class="help-block">*/ ?>
                    <?php /*<strong><?php echo e($errors->first('option')); ?></strong>*/ ?>
                <?php /*</span>*/ ?>
            <?php /*<?php endif; ?>*/ ?>
        <?php /*</div>*/ ?>
    <?php /*</div>*/ ?>

    <div class="form-group<?php echo e($errors->has('url') ? ' has-error' : ''); ?> option-field option-url" <?php if(old('option', 'url') != 'url'): ?> style="display: none;" <?php endif; ?>>
        <label class="col-md-4 control-label">Image URL</label>

        <div class="col-md-6">
            <input type="text" class="form-control" name="url" value="<?php echo e(old('url')); ?>">

            <?php if($errors->has('url')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('url')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>

    <div class="form-group<?php echo e($errors->has('file') ? ' has-error' : ''); ?> option-field option-upload"  <?php if(old('option', 'url') != 'upload'): ?> style="display: none;" <?php endif; ?>>
        <label class="col-md-4 control-label">File (jpg, png)</label>

        <div class="col-md-6">
            <input type="file" class="form-control" name="file" value="<?php echo e(old('file')); ?>">

            <?php if($errors->has('file')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('file')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(document).on("ready", function () {

            $("input[name='option']").on("change", function () {
                showFields($(this).val());
            });

            function showFields(option)
            {
                $(".option-field").hide();
                $(".option-" + option).show();
            }

            showFields("<?php echo e(old('option', 'url')); ?>");

        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('projects.responds.taxonomies.create._base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>