<table class="table custom-table">
    <thead>
        <tr>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
            <th>First name</th>
            <th>Last name</th>
            <th>Created</th>
            <th>Updated</th>
            <th>&nbsp;</th>
            <th>&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($recipients as $recipient): ?>
            <tr <?php if($recipient->chat_disabled): ?> class="text-muted" <?php endif; ?>>
                <td class="text-center">
                    <?php if($recipient->getPhotoUrl('recipient_small')): ?>
                        <img class="img-circle" src="<?php echo e($recipient->getPhotoUrl('recipient_small')); ?>">
                    <?php else: ?>
                        &nbsp;
                    <?php endif; ?>
                </td>
                <td class="text-center">
                    <?php if($recipient->gender == 'male'): ?>
                        <i class="fa fa-mars"></i>
                    <?php elseif($recipient->gender == 'female'): ?>
                        <i class="fa fa-venus"></i>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td><?php echo e($recipient->first_name); ?></td>
                <td><?php echo e($recipient->last_name); ?></td>
                <td><?php echo e($recipient->created_at ? adjust_project_timezone($project, $recipient->created_at)->format('F j, Y, g:i A') : ''); ?></td>
                <td><?php echo e($recipient->updated_at ? adjust_project_timezone($project, $recipient->updated_at)->format('F j, Y, g:i A') : ''); ?></td>
                <td class="text-right">
                    <form method="POST" action="<?php echo e(route('projects.recipients.chat.toggle', [$project->id, $recipient->id])); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if($recipient->chat_disabled): ?>
                            <button class="btn btn-link" type="submit" name="action" value="enable" data-toggle="tooltip" title="Enable chat"><i class="fa fa-toggle-off"></i></button>
                        <?php else: ?>
                            <button class="btn btn-link" type="submit" name="action" value="disable" data-toggle="tooltip" title="Disable chat"><i class="fa fa-toggle-on"></i></button>
                        <?php endif; ?>
                    </form>
                </td>
                <td class="text-right">
                    <a href="<?php echo e(route('projects.recipients.show', [$project->id, $recipient->id])); ?>" class="btn btn-default"><i class="fa fa-arrow-right"></i></a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>