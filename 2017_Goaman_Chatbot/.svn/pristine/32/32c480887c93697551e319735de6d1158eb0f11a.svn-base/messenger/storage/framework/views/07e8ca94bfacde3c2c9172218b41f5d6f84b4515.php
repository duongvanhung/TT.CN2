<div class="form-group">
    <label class="col-md-4 control-label">Option</label>

    <div class="col-md-6">
        <p class="form-control-static"><?php echo e($param->value); ?></p>
    </div>
</div>