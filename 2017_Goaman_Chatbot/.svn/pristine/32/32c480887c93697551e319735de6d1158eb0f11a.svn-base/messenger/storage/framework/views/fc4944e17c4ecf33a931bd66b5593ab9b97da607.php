<div class="form-group">
    <label class="col-md-4 control-label">Image URL</label>

    <div class="col-md-6">
        <p class="form-control-static"><?php echo e($param->value); ?></p>
    </div>
</div>

<div class="form-group">
    <div class="col-md-6 col-md-push-4">
        <p class="form-control-static">
            <img src="<?php echo e($param->value); ?>">
        </p>
    </div>
</div>