<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="<?php echo e(route('projects.show', $project->id)); ?>"><?php echo e($project->title); ?></a> &raquo; Recipients</div>
                <div class="pull-right">
                    <a href="<?php echo e(route('projects.settings', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="<?php echo e(route('projects.recipients.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="<?php echo e(route('projects.recipients.variables.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="<?php echo e(route('projects.responds.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="<?php echo e(route('projects.messages.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="<?php echo e(route('projects.subscriptions.channels.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php echo app('notification')->container()->show(); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Growth of recipients list of last 30 days</div>
                    <div class="panel-body">
                        <?php echo app("arrilot.widget")->run('App\Widgets\Statistics\Project\RecipientsGrowth', ['project' => $project]); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-md-push-2">
                <div class="panel panel-default">
                    <form method="GET" action="<?php echo e(route('projects.recipients.index', ['project' => $project->id])); ?>">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Search for..." value="<?php echo e($search); ?>">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default<?php echo e($search && count($recipients) <= 0 ? ' panel-info' : ''); ?>">
                    <?php if(count($recipients) <= 0): ?>
                        <div class="panel-body">
                            <?php if($search): ?>
                                No recipients found.
                            <?php else: ?>
                                You have no recipients in this project!
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <?php echo $__env->make('projects.recipients._partials.table', ['recipients' => $recipients], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if($recipients->hasPages()): ?>
            <div class="text-center">
                <?php echo $recipients->render(); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>