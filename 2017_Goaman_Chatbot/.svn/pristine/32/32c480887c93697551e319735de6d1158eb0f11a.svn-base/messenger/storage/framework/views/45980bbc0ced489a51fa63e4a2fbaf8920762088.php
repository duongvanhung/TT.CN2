<?php $__env->startSection('form'); ?>
    <div class="form-group<?php echo e($errors->has('text') ? ' has-error' : ''); ?>">
        <label class="col-md-4 control-label">Text</label>

        <div class="col-md-6">
            <textarea rows="5" class="form-control" name="text"><?php echo e(old('text', $taxonomy->getParamValue('text'))); ?></textarea>

            <?php if($errors->has('text')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('text')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('projects.responds.taxonomies.edit._base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>