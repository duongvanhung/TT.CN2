<div class="form-group text-right">
    <div class="col-md-6 col-md-offset-6 text-right">
        <a href="<?php echo e(route('projects.responds.edit.taxonomies.create', [$project->id, $respond->id, 'button', $taxonomy->id])); ?>" class="btn btn-primary">
            <i class="fa fa-btn fa-plus"></i>Add new element
        </a>
    </div>
</div>