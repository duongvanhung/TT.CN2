<?php $__env->startSection('form'); ?>
    <input type="hidden" name="option" value="<?php echo e($taxonomy->getParamValue('option')); ?>">

    <div class="form-group<?php echo e($errors->has('url') ? ' has-error' : ''); ?>">
        <label class="col-md-4 control-label">Video URL</label>

        <div class="col-md-6">
            <input type="text" class="form-control" name="url" value="<?php echo e(old('url', $taxonomy->getParamValue('url'))); ?>">

            <?php if($errors->has('url')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('url')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('projects.responds.taxonomies.edit._base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>