<table class="table custom-table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Accessor</th>
            <th>Type</th>
            <th>Created</th>
            <th>Updated</th>
            <th>&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($recipientsVariables as $recipientsVariable): ?>
            <tr>
                <td><?php echo e($recipientsVariable->name); ?></td>
                <td>{$<?php echo e($recipientsVariable->accessor); ?>}</td>
                <td><?php echo e($recipientsVariable->type); ?></td>
                <td><?php echo e($recipientsVariable->created_at ? adjust_project_timezone($project, $recipientsVariable->created_at)->format('F j, Y, g:i A') : ''); ?></td>
                <td><?php echo e($recipientsVariable->updated_at ? adjust_project_timezone($project, $recipientsVariable->updated_at)->format('F j, Y, g:i A') : ''); ?></td>
                <td class="text-right">
                    <form method="POST" action="<?php echo e(route('projects.recipients.variables.delete', [$project->id, $recipientsVariable->id])); ?>">
                        <?php echo csrf_field(); ?>

                        <?php echo method_field('DELETE'); ?>

                        <?php if (Gate::check('delete', [$recipientsVariable, $project])): ?>
                            <button type="submit" class="btn btn-danger confirm-action" data-toggle="tooltip" title="Delete"><i class="fa fa-trash"></i></button>
                        <?php endif; ?>
                        <?php if (Gate::check('edit', [$recipientsVariable, $project])): ?>
                            <a href="<?php echo e(route('projects.recipients.variables.edit', [$project->id, $recipientsVariable->id])); ?>" class="btn btn-warning" data-toggle="tooltip" title="Edit"><i class="fa fa-pencil"></i></a>
                        <?php endif; ?>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>