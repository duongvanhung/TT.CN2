<div class="taxonomy-group">
    <div class="clearfix taxonomy-group-toolbar">
        <small class="pull-left taxonomy-type"><?php echo e($taxonomy->type); ?></small>
        <div class="pull-right taxonomy-toolbar">
            <?php if(!$taxonomy->is_first): ?>
                <a href="<?php echo e(route('projects.responds.edit.taxonomies.move.down', [$project->id, $respond->id, $taxonomy->id])); ?>" class="btn btn-xs btn-default" data-toggle="tooltip" title="Move up"><i class="fa fa-arrow-up"></i></a>
            <?php endif; ?>
            <?php if(!$taxonomy->is_last): ?>
                <a href="<?php echo e(route('projects.responds.edit.taxonomies.move.up', [$project->id, $respond->id, $taxonomy->id])); ?>" class="btn btn-xs btn-default" data-toggle="tooltip" title="Move down"><i class="fa fa-arrow-down"></i></a>
            <?php endif; ?>
            <a href="<?php echo e(route('projects.responds.edit.taxonomies.delete', [$project->id, $respond->id, $taxonomy->id])); ?>" class="btn btn-xs btn-danger confirm-action" data-toggle="tooltip" title="Delete"><i class="fa fa-trash"></i></a>
            <a href="<?php echo e(route('projects.responds.edit.taxonomies.edit', [$project->id, $respond->id, $taxonomy->id])); ?>" class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit"><i class="fa fa-pencil"></i></a>
        </div>
    </div>
    <div class="taxonomy-group-params">
        <?php foreach($taxonomy->params()->ordered()->get() as $param): ?>
            <?php echo $__env->make('projects.responds.taxonomies.render.'.$taxonomy->type.'.'.$param->key, ['project' => $project, 'respond' => $respond, 'taxonomy' => $taxonomy, 'param' => $param], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; ?>
    </div>

    <?php foreach($taxonomy->children()->ordered()->get() as $child): ?>
        <?php echo $__env->make('projects.responds.taxonomies.render.render', ['project' => $project, 'respond' => $respond, 'taxonomy' => $child], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; ?>

    <?php if(view()->exists('projects.responds.taxonomies.render._actions.'.$taxonomy->type)): ?>
        <div class="taxonomy-group-bottom-toolbar">
            <?php echo $__env->make('projects.responds.taxonomies.render._actions.'.$taxonomy->type, ['project' => $project, 'respond' => $respond, 'taxonomy' => $taxonomy], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    <?php endif; ?>
</div>