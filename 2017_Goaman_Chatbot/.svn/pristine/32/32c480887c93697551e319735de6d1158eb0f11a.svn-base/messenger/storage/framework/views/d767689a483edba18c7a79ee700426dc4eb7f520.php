<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container">
            <div class="clearfix">
                <div class="pull-left"><a href="<?php echo e(route('projects.show', $project->id)); ?>"><?php echo e($project->title); ?></a> &raquo; Recipients variables</div>
                <div class="pull-right">
                    <a href="<?php echo e(route('projects.settings', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Settings"><i class="fa fa-cog"></i></a>
                    <a href="<?php echo e(route('projects.recipients.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Recipients"><i class="fa fa-users"></i></a>
                    <a href="<?php echo e(route('projects.recipients.variables.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Recipients variables"><i class="fa fa-i-cursor"></i></a>
                    <a href="<?php echo e(route('projects.responds.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Responds"><i class="fa fa-comment"></i></a>
                    <a href="<?php echo e(route('projects.messages.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Mass messages"><i class="fa fa-envelope"></i></a>
                    <a href="<?php echo e(route('projects.subscriptions.channels.index', $project->id)); ?>" class="btn btn-primary" data-toggle="tooltip" title="Subscription channels"><i class="fa fa-rss"></i></a>
                    <a href="<?php echo e(route('projects.recipients.variables.create', $project->id)); ?>" class="btn btn-success"><i class="fa fa-btn fa-plus"></i>Add variable</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php echo app('notification')->container()->show(); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <?php if(count($recipientsVariables) <= 0): ?>
                        <div class="panel-body">
                            You have no variables in this project! <a href="<?php echo e(route('projects.recipients.variables.create', $project->id)); ?>">Add</a> new variable.
                        </div>
                    <?php else: ?>
                        <?php echo $__env->make('projects.recipients.variables._partials.table', ['recipientsVariables' => $recipientsVariables], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if($recipientsVariables->hasPages()): ?>
            <div class="text-center">
                <?php echo $recipientsVariables->render(); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>