<div class="form-group">
    <label class="col-md-4 control-label">Sub-Title</label>

    <div class="col-md-6">
        <p class="form-control-static">{{ $param->value }}</p>
    </div>
</div>