<div class="form-group">
    <label class="col-md-4 control-label">Text for a link to an article</label>

    <div class="col-md-6">
        <p class="form-control-static">{{ $param->value }}</p>
    </div>
</div>