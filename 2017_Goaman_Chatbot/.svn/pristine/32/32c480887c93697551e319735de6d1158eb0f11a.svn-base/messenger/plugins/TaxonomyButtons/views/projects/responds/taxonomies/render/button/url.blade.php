<div class="form-group">
    <label class="col-md-4 control-label">URL</label>

    <div class="col-md-6">
        <p class="form-control-static">{{ $param->value }} <a href="{{ $param->value }}" target="_blank"><i class="fa fa-external-link"></i></a></p>
    </div>
</div>