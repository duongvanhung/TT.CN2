<div class="form-group">
    <label class="col-md-4 control-label">Video URL</label>

    <div class="col-md-6">
        <p class="form-control-static">
            <a href="{{ $param->value }}">{{ $param->value }}</a>
        </p>
    </div>
</div>