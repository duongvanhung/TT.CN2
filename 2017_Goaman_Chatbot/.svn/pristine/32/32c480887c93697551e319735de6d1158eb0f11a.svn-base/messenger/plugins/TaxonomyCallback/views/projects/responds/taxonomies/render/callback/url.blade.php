<div class="form-group">
    <label class="col-md-4 control-label">Callback URL</label>

    <div class="col-md-6">
        <p class="form-control-static"><a href="{{ $param->value }}" target="_blank">{{ $param->value }}</a></p>
    </div>
</div>