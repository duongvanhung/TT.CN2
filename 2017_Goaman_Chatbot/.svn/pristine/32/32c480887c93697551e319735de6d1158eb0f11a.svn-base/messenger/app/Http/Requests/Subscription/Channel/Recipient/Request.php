<?php

namespace App\Http\Requests\Subscription\Channel\Recipient;

use App\Http\Requests;
use Gate;

abstract class Request extends Requests\Request
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'recipient' => 'required',
            'recipient.*' => 'exists:recipients,id,project_id,' . $this->route('project')->id,
        ];
    }
}
