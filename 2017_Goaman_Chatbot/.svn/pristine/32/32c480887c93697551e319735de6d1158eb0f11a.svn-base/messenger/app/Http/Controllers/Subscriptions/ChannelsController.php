<?php

namespace App\Http\Controllers\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\Subscription\Channel\CreateRequest;
use App\Http\Requests\Subscription\Channel\UpdateRequest;
use App\Models\Project;
use App\Models\Subscription\Channel;
use Illuminate\Http\Request;
use Notification;

class ChannelsController extends Controller
{
    /**
     * @param Request $request
     * @param Project $project
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(Request $request, Project $project)
    {
        $this->authorize('view', $project);

        $search = $request->get('search');

        $channels = $project->subscriptionsChannels()->ordered();

        if ($search) {
            $channels = $channels->where('name', 'like', '%'.$search.'%');
        }

        $channels = $channels->paginate(30);

        if ($search) {
            $channels->appends(['search' => $search]);
        }

        return view('projects.subscriptions.channels.index', [
            'project' => $project,
            'channels' => $channels,
            'search' => $search,
        ]);
    }

    /**
     * @param Project $project
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create(Project $project)
    {
        $this->authorize('view', $project);

        return view('projects.subscriptions.channels.create', [
            'project' => $project,
        ]);
    }

    /**
     * @param CreateRequest $request
     * @param Project $project
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateRequest $request, Project $project)
    {
        $this->authorize('view', $project);

        $channel = new Channel(['name' => $request->get('name')]);

        $channel->project()->associate($project);

        $channel->save();

        Notification::success('Subscription channel added successfully.');

        return redirect()->route('projects.subscriptions.channels.index', $project->id);
    }

    /**
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit(Project $project, Channel $channel)
    {
        $this->authorize('edit', [$channel, $project]);

        return view('projects.subscriptions.channels.edit', [
            'project' => $project,
            'channel' => $channel,
        ]);
    }

    /**
     * @param UpdateRequest $request
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, Project $project, Channel $channel)
    {
        $this->authorize('edit', [$channel, $project]);

        $channel->fill(['name' => $request->get('name')]);

        Notification::success('Subscription channel updated successfully.');

        return redirect()->route('projects.subscriptions.channels.show', [$project->id, $channel->id]);
    }

    /**
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show(Project $project, Channel $channel)
    {
        $this->authorize('view', [$channel, $project]);

        return view('projects.subscriptions.channels.show', [
            'project' => $project,
            'channel' => $channel,
            'broadcasts' => $channel->broadcasts()->ordered()->take(10)->get(),
            'recipients' => $channel->recipients()->orderBy('pivot_created_at', 'desc')->take(10)->get(),
        ]);
    }

    /**
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function delete(Project $project, Channel $channel)
    {
        $this->authorize('delete', [$channel, $project]);

        $channel->delete();

        Notification::success('Subscription channel deleted successfully.');

        return redirect()->route('projects.subscriptions.channels.index', $project->id);
    }
}
