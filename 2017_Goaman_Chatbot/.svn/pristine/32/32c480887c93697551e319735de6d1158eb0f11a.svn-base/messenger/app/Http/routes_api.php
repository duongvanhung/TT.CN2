<?php

Route::group(['prefix' => 'api', 'namespace' => 'Api'], function () {

    Route::post('/validate/matcher', [
        'uses' => 'ValidateController@validateMatcher',
        'as' => 'api.validate.matcher',
    ]);

    Route::get('/project/{project}/analytics', [
        'uses' => 'ProjectController@analytics',
        'as' => 'api.project.analytics',
    ]);

    Route::resource('project', 'ProjectController', [
        'only' => ['show'],
    ]);

    Route::post('/project/{project}/page/connect', [
        'uses' => 'ProjectController@connectPage',
        'as' => 'api.project.page.connect',
    ]);

    Route::delete('/project/{project}/page/disconnect', [
        'uses' => 'ProjectController@disconnectPage',
        'as' => 'api.project.page.disconnect',
    ]);

    Route::resource('project.respond', 'ProjectRespondController', [
        'only' => ['index', 'destroy'],
    ]);

    Route::post('/project/{project}/flow/sort', [
        'uses' => 'ProjectFlowController@updateSort',
        'as' => 'api.project.flow.sort',
    ]);

    Route::resource('project.flow', 'ProjectFlowController', [
        'only' => ['show', 'index', 'store', 'destroy', 'update'],
    ]);

    Route::post('/project/{project}/flow/{flow}/default', [
        'uses' => 'ProjectFlowController@makeDefault',
        'as' => 'api.project.flow.default',
    ]);

    Route::delete('/project/{project}/flow/{flow}/default', [
        'uses' => 'ProjectFlowController@deleteDefault',
        'as' => 'api.project.flow.default.delete',
    ]);

    Route::resource('project.flow.matcher', 'ProjectFlowMatcherController', [
        'only' => ['destroy', 'store', 'update'],
    ]);

});
