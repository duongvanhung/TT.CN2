<?php

namespace App\Http\Requests\Mass\Message;

use App\Http\Requests;
use Gate;

abstract class Request extends Requests\Request
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required',
            'responds' => 'required|min:1',
            'responds.*' => 'exists:responds,id,label,NULL,project_id,'.$this->route('project')->id,
            'recipients.*' => 'exists:recipients,id,project_id,'.$this->route('project')->id,
            'interval' => 'integer|min:1',
            'scheduled_at' => 'required|date',
            'timezone' => 'required|in:recipient,project',
        ];
    }
}
