<?php

namespace App\Http\Requests\Subscription\Channel\Broadcast;

use App\Http\Requests;
use Gate;

abstract class Request extends Requests\Request
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required',
            'respond' => 'required|exists:responds,id,project_id,' . $this->route('project')->id,
            'interval' => 'integer|min:1',
            'scheduled_at' => 'required|date',
            'timezone' => 'required|in:recipient,project',
        ];
    }
}
