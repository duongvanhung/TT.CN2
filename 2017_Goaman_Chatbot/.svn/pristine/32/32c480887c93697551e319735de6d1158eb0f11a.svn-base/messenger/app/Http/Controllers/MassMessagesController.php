<?php

namespace App\Http\Controllers;

use App\Http\Requests\Mass\Message\CreateRequest;
use App\Jobs\Mass\Message\ScheduleJob;
use App\Models\Mass\Message;
use App\Models\Project;
use App\Models\Communication;
use Carbon\Carbon;
use Illuminate\Contracts\Bus\Dispatcher;
use Notification;

class MassMessagesController extends Controller
{
    /**
     * @param Project $project
     * @return \Illuminate\Http\Response
     */
    public function index(Project $project)
    {
        $this->authorize('view', $project);

        $messages = $project->massMessages()->orderBy('scheduled_at', 'desc')->paginate(30);

        return view('projects.messages.index', [
            'project' => $project,
            'messages' => $messages,
        ]);
    }

    /**
     * @param Project $project
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create(Project $project)
    {
        $this->authorize('view', $project);

        return view('projects.messages.create', [
            'project' => $project,
            'responds' => $project->responds()->global()->get(),
            'recipients' => $project->recipients()->orderBy('first_name', 'asc')->orderBy('last_name', 'asc')->get(),
        ]);
    }

    /**
     * @param CreateRequest $request
     * @param Dispatcher $dispatcher
     * @param Project $project
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function store(CreateRequest $request, Dispatcher $dispatcher, Project $project)
    {
        $this->authorize('view', $project);

        $currentTZ = date_default_timezone_get();

        date_default_timezone_set($project->timezone);

        $scheduledAt = new Carbon($request->get('scheduled_at'));
        $scheduledAt->setTimezone($currentTZ);

        date_default_timezone_set($currentTZ);

        $message = new Message([
            'name' => $request->get('name'),
            'scheduled_at' => new Carbon($scheduledAt),
        ]);

        $message->project()->associate($project);

        $message->save();

        $message->responds()->sync((array) $request->get('responds', []));

        $dispatcher->dispatchNow(new ScheduleJob(
            $message,
            count((array) $request->get('recipients', [])) > 0
            ? $project->recipients()->whereIn('id', $request->get('recipients'))->get()->all()
            : [],
            (int) $request->get('interval', 0),
            $request->get('timezone')
        ));

        Notification::success('Message scheduled successfully.');

        return redirect()->route('projects.messages.show', [$project->id, $message->id]);
    }

    /**
     * @param Project $project
     * @param Message $message
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show(Project $project, Message $message)
    {
        $this->authorize('view', [$message, $project]);

        $schedules = Message\Schedule::with('recipient')
            ->where('mass_message_id', $message->id)
            ->orderBy('scheduled_at', 'asc')
            ->paginate(30);

        return view('projects.messages.show', [
            'project' => $project,
            'message' => $message,
            'schedules' => $schedules,
        ]);
    }

    /**
     * @param Project $project
     * @param Message $message
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function delete(Project $project, Message $message)
    {
        $this->authorize('delete', [$message, $project]);

        $message->delete();

        Notification::success('Message deleted successfully.');

        return redirect()->route('projects.messages.index', $project->id);
    }
}
