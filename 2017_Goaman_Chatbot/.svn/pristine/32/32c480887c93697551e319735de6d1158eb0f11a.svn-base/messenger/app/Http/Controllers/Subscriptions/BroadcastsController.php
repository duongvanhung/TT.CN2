<?php

namespace App\Http\Controllers\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\Subscription\Channel\Broadcast\CreateRequest;
use App\Jobs\Subscription\Channel\Broadcast\ScheduleJob;
use App\Models\Project;
use App\Models\Recipient;
use App\Models\Subscription\Channel;
use Carbon\Carbon;
use Illuminate\Contracts\Bus\Dispatcher;
use Illuminate\Http\Request;
use Notification;

class BroadcastsController extends Controller
{
    /**
     * @param Request $request
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(Request $request, Project $project, Channel $channel)
    {
        $this->authorize('view', [$channel, $project]);

        $search = $request->get('search');

        $broadcasts = $channel->broadcasts()->ordered();

        if ($search) {
            $broadcasts = $broadcasts->where('created_at', 'like', '%'.$search.'%');
        }

        $broadcasts = $broadcasts->paginate(30);

        if ($search) {
            $broadcasts->appends(['search' => $search]);
        }

        return view('projects.subscriptions.channels.broadcasts.index', [
            'project' => $project,
            'channel' => $channel,
            'broadcasts' => $broadcasts,
            'search' => $search,
        ]);
    }

    /**
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create(Project $project, Channel $channel)
    {
        $this->authorize('view', [$channel, $project]);

        return view('projects.subscriptions.channels.broadcasts.create', [
            'project' => $project,
            'channel' => $channel,
            'responds' => $project->responds()->get(),
        ]);
    }

    /**
     * @param CreateRequest $request
     * @param Dispatcher $dispatcher
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateRequest $request, Dispatcher $dispatcher, Project $project, Channel $channel)
    {
        $this->authorize('view', [$channel, $project]);

        $currentTZ = date_default_timezone_get();

        date_default_timezone_set($project->timezone);

        $scheduledAt = new Carbon($request->get('scheduled_at'));
        $scheduledAt->setTimezone($currentTZ);

        date_default_timezone_set($currentTZ);

        $broadcast = new Channel\Broadcast([
            'name' => $request->get('name'),
            'scheduled_at' => new Carbon($scheduledAt),
        ]);

        $broadcast->channel()->associate($channel);
        $broadcast->respond()->associate($project->responds()->findOrFail($request->get('respond')));

        $broadcast->save();

        $dispatcher->dispatchNow(new ScheduleJob(
            $broadcast,
            (int) $request->get('interval', 0),
            $request->get('timezone')
        ));

        Notification::success('Broadcast scheduled successfully.');

        return redirect()->route('projects.subscriptions.channels.broadcasts.index', [$project->id, $channel->id]);
    }

    /**
     * @param Project $project
     * @param Channel $channel
     * @param Channel\Broadcast $broadcast
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show(Project $project, Channel $channel, Channel\Broadcast $broadcast)
    {
        $this->authorize('view', [$broadcast, $channel, $project]);

        $schedules = Channel\Broadcast\Schedule::with('recipient')
            ->where('broadcast_id', $broadcast->id)
            ->orderBy('scheduled_at', 'asc')
            ->paginate(30);

        return view('projects.subscriptions.channels.broadcasts.show', [
            'project' => $project,
            'channel' => $channel,
            'broadcast' => $broadcast,
            'schedules' => $schedules,
        ]);
    }

    /**
     * @param Project $project
     * @param Channel $channel
     * @param Channel\Broadcast $broadcast
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Project $project, Channel $channel, Channel\Broadcast $broadcast)
    {
        $this->authorize('delete', [$broadcast, $channel, $project]);

        $broadcast->delete();

        Notification::success('Broadcast deleted successfully.');

        return redirect()->route('projects.subscriptions.channels.broadcasts.index', [$project->id, $channel->id]);
    }
}
