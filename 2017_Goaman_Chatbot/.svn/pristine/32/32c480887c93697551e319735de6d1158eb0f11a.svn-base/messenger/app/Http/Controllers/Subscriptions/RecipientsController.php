<?php

namespace App\Http\Controllers\Subscriptions;

use App\Http\Controllers\Controller;
use App\Http\Requests\Subscription\Channel\Recipient\CreateRequest;
use App\Jobs\Subscription\Channel\AddSubscriberJob;
use App\Jobs\Subscription\Channel\RemoveSubscriberJob;
use App\Models\Project;
use App\Models\Recipient;
use App\Models\Subscription\Channel;
use Illuminate\Contracts\Bus\Dispatcher;
use Illuminate\Http\Request;
use Notification;

class RecipientsController extends Controller
{
    /**
     * @param Request $request
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(Request $request, Project $project, Channel $channel)
    {
        $this->authorize('view', [$channel, $project]);

        $search = $request->get('search');

        $recipients = $channel->recipients()->orderBy('first_name', 'asc')->orderBy('last_name', 'asc');

        if ($search) {
            $recipients = $recipients
                ->where('first_name', 'like', '%'.$search.'%')
                ->orWhere('last_name', 'like', '%'.$search.'%');
        }

        $recipients = $recipients->paginate(30);

        if ($search) {
            $recipients->appends(['search' => $search]);
        }

        return view('projects.subscriptions.channels.recipients.index', [
            'project' => $project,
            'channel' => $channel,
            'recipients' => $recipients,
            'search' => $search,
        ]);
    }

    /**
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create(Project $project, Channel $channel)
    {
        $this->authorize('view', [$channel, $project]);

        $recipients = Recipient::select('recipients.*')
            ->where('recipients.project_id', $project->id)
            ->whereNotExists(function ($query) use ($channel) {
                $query
                    ->select('subscriptions_channels_recipients.*')
                    ->from('subscriptions_channels_recipients')
                    ->where('subscriptions_channels_recipients.channel_id', $channel->id)
                    ->where('recipients.id', \DB::raw('subscriptions_channels_recipients.recipient_id'));
            })
            ->get();

        return view('projects.subscriptions.channels.recipients.create', [
            'project' => $project,
            'channel' => $channel,
            'recipients' => $recipients,
        ]);
    }

    /**
     * @param CreateRequest $request
     * @param Dispatcher $dispatcher
     * @param Project $project
     * @param Channel $channel
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(CreateRequest $request, Dispatcher $dispatcher, Project $project, Channel $channel)
    {
        $this->authorize('view', [$channel, $project]);

        foreach ((array) $request->get('recipient', []) as $recipient) {
            try {
                $dispatcher->dispatchNow(new AddSubscriberJob(
                    $channel,
                    $project->recipients()->findOrFail($recipient),
                    'manual'
                ));
            } catch (\Exception $e) {
                logger($e);
            }
        }

        Notification::success('Recipients were added successfully.');

        return redirect()->route('projects.subscriptions.channels.recipients.index', [$project->id, $channel->id]);
    }

    /**
     * @param Project $project
     * @param Dispatcher $dispatcher
     * @param Channel $channel
     * @param Recipient $recipient
     * @return \Illuminate\Http\RedirectResponse
     */
    public function delete(Project $project, Dispatcher $dispatcher, Channel $channel, Recipient $recipient)
    {
        $this->authorize('delete', [$channel, $project]);

        try {
            $dispatcher->dispatchNow(new RemoveSubscriberJob($channel, $recipient));
        } catch (\Exception $e) {
            logger($e);
        }

        Notification::success('Recipient removed from channel successfully.');

        return redirect()->back();
    }
}
