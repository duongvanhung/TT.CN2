<?php

namespace App\Http\Controllers;

use App\Http\Requests\Recipient\ChatToggleRequest;
use App\Http\Requests\Recipient\UpdateRequest;
use App\Jobs\Recipients\AssignVariablesJob;
use App\Jobs\Recipients\Chat\DisableJob;
use App\Jobs\Recipients\Chat\EnableJob;
use App\Jobs\Recipients\FetchRecipientDataJob;
use App\Models\Project;
use App\Models\Recipient;
use App\Models\Communication;
use Illuminate\Contracts\Bus\Dispatcher;
use Illuminate\Http\Request;
use Notification;

class RecipientsController extends Controller
{
    /**
     * Show links list.
     *
     * @param Request $request
     * @param Project $project
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, Project $project)
    {
        $this->authorize('view', $project);

        $search = $request->get('search');

        $recipients = $project->recipients()->orderBy('first_name', 'asc')->orderBy('last_name', 'asc');

        if ($search) {
            $recipients = $recipients->where(function ($query) use ($search) {
                return $query
                    ->orWhere('reference', 'like', '%'.$search.'%')
                    ->orWhere('first_name', 'like', '%'.$search.'%')
                    ->orWhere('last_name', 'like', '%'.$search.'%');
            });
        }

        $recipients = $recipients->paginate(30);

        if ($search) {
            $recipients->appends(['search' => $search]);
        }

        return view('projects.recipients.index', [
            'project' => $project,
            'recipients' => $recipients,
            'search' => $search,
        ]);
    }

    /**
     * Show project dashboard.
     *
     * @param Request $request
     * @param Project $project
     * @param Recipient $recipient
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function show(Request $request, Project $project, Recipient $recipient)
    {
        $this->authorize('view', [$recipient, $project]);

        $search = $request->get('search');

        $communicationLog = Communication\Log::with('flow', 'recipient')
            ->where('project_id', $project->id)
            ->where('recipient_id', $recipient->id)
            ->orderBy('created_at', 'desc');

        if ($search) {
            $communicationLog = $communicationLog->where('message', 'like', '%'.$search.'%');
        }

        $communicationLog = $communicationLog->paginate(30);

        $recipientVariables = Recipient\Variable\Relation::with('variable', 'values')
            ->where('recipient_id', $recipient->id)
            ->get();

        return view('projects.recipients.show', [
            'project' => $project,
            'recipient' => $recipient,
            'recipientVariables' => $recipientVariables,
            'communication_log' => $communicationLog,
            'subscriptions_channels' => $recipient->subscriptionsChannels,
            'search' => $search,
        ]);
    }

    /**
     * @param Project $project
     * @param Recipient $recipient
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit(Project $project, Recipient $recipient)
    {
        $this->authorize('edit', [$recipient, $project]);

        $recipientVariables = Recipient\Variable\Relation::with('variable', 'values')
            ->where('recipient_id', $recipient->id)
            ->get()
            ->keyBy(function (Recipient\Variable\Relation $relation) {
                return $relation->variable->accessor;
            });

        return view('projects.recipients.edit', [
            'project' => $project,
            'recipient' => $recipient,
            'recipientVariables' => $recipientVariables,
        ]);
    }

    /**
     * @param UpdateRequest $request
     * @param Dispatcher $dispatcher
     * @param Project $project
     * @param Recipient $recipient
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateRequest $request, Dispatcher $dispatcher, Project $project, Recipient $recipient)
    {
        $this->authorize('edit', [$recipient, $project]);

        $dispatcher->dispatchNow(new AssignVariablesJob($recipient, (array) $request->get('variables', [])));

        Notification::success('Recipient updated successfully.');

        return redirect()->route('projects.recipients.show', [$project->id, $recipient->id]);
    }

    /**
     * @param ChatToggleRequest $request
     * @param Dispatcher $dispatcher
     * @param Project $project
     * @param Recipient $recipient
     * @return \Illuminate\Http\RedirectResponse
     */
    public function chatToggle(
        ChatToggleRequest $request,
        Dispatcher $dispatcher,
        Project $project,
        Recipient $recipient
    ) {
        $this->authorize('edit', [$recipient, $project]);

        $dispatcher->dispatchNow(
            $request->get('action') == 'enable' ? new EnableJob($recipient) : new DisableJob($recipient)
        );

        Notification::success('Recipient chat status updated successfully.');

        return redirect()->back();
    }

    /**
     * @param Dispatcher $dispatcher
     * @param Project $project
     * @param Recipient $recipient
     * @return \Illuminate\Http\RedirectResponse
     */
    public function refresh(Dispatcher $dispatcher, Project $project, Recipient $recipient)
    {
        $this->authorize('view', [$recipient, $project]);

        $data = $dispatcher->dispatchNow(new FetchRecipientDataJob(
            $recipient->reference,
            $recipient->project->page_token
        ));

        $recipient->fill([
            'first_name' => array_get($data, 'first_name'),
            'last_name' => array_get($data, 'last_name'),
            'locale' => array_get($data, 'locale'),
            'gender' => array_get($data, 'gender'),
            'timezone' => timezone_gmt_name_from_offset(array_get($data, 'timezone')),
            'photo' => array_get($data, 'profile_pic'),
        ]);

        $recipient->save();

        Notification::success('Recipient data updated!');

        return redirect()->route('projects.recipients.show', [$project->id, $recipient->id]);
    }
}
