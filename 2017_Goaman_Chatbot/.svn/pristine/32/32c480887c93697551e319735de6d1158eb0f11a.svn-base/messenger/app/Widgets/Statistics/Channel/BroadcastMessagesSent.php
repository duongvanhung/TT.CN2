<?php

namespace App\Widgets\Statistics\Channel;

use Arrilot\Widgets\AbstractWidget;
use App\Services\Statistics;
use Carbon\Carbon;

class BroadcastMessagesSent extends AbstractWidget
{
    /**
     * The configuration array.
     *
     * @var array
     */
    protected $config = [
        'channel' => null,
    ];

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function run()
    {
        /** @var Statistics\Channel $service */
        $service = app(Statistics\Channel::class);

        $statistics = $service->getValues(
            $this->config['channel'],
            ['broadcast_messages_sent'],
            new Carbon('-30 days')
        );

        $labels = array_keys($statistics);

        $broadcastMessagesSent = $this->extract('broadcast_messages_sent', $statistics, $labels);

        return view('widgets.statistics.channel.broadcast_messages_sent', [
            'labels' => $labels,
            'broadcast_messages_sent' => $broadcastMessagesSent,
        ]);
    }

    /**
     * @param $key
     * @param array $statistics
     * @param array $labels
     * @return array
     */
    protected function extract($key, array $statistics, array $labels)
    {
        $data = [];

        foreach ($labels as $label) {
            $data[$label] = array_get($statistics, $label.'.'.$key, 0);
        }

        return $data;
    }

    /**
     * @return Carbon
     */
    protected function getMinDate()
    {
        return new Carbon($this->config['channel']->statistics()->where('key', 'subscribers')->min('date_at'));
    }
}
