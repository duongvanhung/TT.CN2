<?php

namespace App\Widgets\Statistics\Channel;

use Arrilot\Widgets\AbstractWidget;
use App\Services\Statistics;
use Carbon\Carbon;
use DB;

class SubscribersGrowth extends AbstractWidget
{
    /**
     * The configuration array.
     *
     * @var array
     */
    protected $config = [
        'channel' => null,
    ];

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function run()
    {
        /** @var Statistics\Channel $service */
        $service = app(Statistics\Channel::class);

        $statistics = $service->getValues($this->config['channel'], ['subscribers'], new Carbon('-30 days'));

        $totalBefore = (int) array_get($service->sumValues(
            $this->config['channel'],
            ['subscribers'],
            $this->getMinDate(),
            new Carbon('-29 days')
        ), 'subscribers', 0);

        $labels = array_keys($statistics);

        $subscribers = $this->extract('subscribers', $statistics, $labels);

        $totals = [];

        foreach ($subscribers as $key => $value) {
            $totalBefore += $value;
            $totals[$key] = $totalBefore;
        }

        return view('widgets.statistics.channel.subscribers_growth', [
            'labels' => $labels,
            'subscribers' => $subscribers,
            'totals' => $totals,
        ]);
    }

    /**
     * @param $key
     * @param array $statistics
     * @param array $labels
     * @return array
     */
    protected function extract($key, array $statistics, array $labels)
    {
        $data = [];

        foreach ($labels as $label) {
            $data[$label] = array_get($statistics, $label.'.'.$key, 0);
        }

        return $data;
    }

    /**
     * @return Carbon
     */
    protected function getMinDate()
    {
        return new Carbon($this->config['channel']->statistics()->where('key', 'subscribers')->min('date_at'));
    }
}
